OLD TOWNS WALKS - SITEMAP FIX

Replace the project-root astro.config.mjs with the included file.

What this fixes:
- The current sitemap contains only the small set of statically generated routes.
- Dynamic /[lang]/walks/[id], /cities/[city], and /countries/[country] routes were missing.
- Static redirect/noindex utility pages are intentionally excluded from the sitemap.
- The sitemap is generated automatically from src/data/videos.json on every build.

After replacement run:

npm run build

During build you should see lines similar to:
[sitemap] Source videos: ...
[sitemap] Eligible videos: ...
[sitemap] Cities: ...
[sitemap] Countries: ...
[sitemap] Generated URLs: ...

Do not deploy until the generated URL count is in the expected tens of thousands.

Then inspect:
Get-ChildItem .\dist\client\sitemap*.xml | Select-Object Name,Length

After approval:
npx wrangler deploy

Then rerun:
node .\audit-sitemap.mjs
