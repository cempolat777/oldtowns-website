OLD TOWNS WALKS - NOINDEX SITEMAP FIX

This version keeps the working dynamic sitemap, but now uses
src/lib/videoSeo.ts -> getVideoIndexDecision() as the single source
of truth for video sitemap eligibility.

Why:
- Live audit found 28,926 sitemap URLs.
- 25,182 were indexable.
- 3,744 were noindex.
- 3,744 / 18 languages = 208 videos.
- videos.json itself had only 50 explicit indexStatus=index and 1,454 empty,
  so the noindex decision is being computed by videoSeo.ts quality/evidence
  rules, not by the raw indexStatus field alone.

Expected result after build:
- Sitemap-eligible videos: 1,296
- Excluded noindex videos: 208
- Generated URLs: 25,182

Steps:
1) Replace project-root astro.config.mjs with this file.
2) Run:
   npm run build
3) Confirm the sitemap log numbers.
4) Do NOT deploy if the generated URL count is not around 25,182.
5) If correct, deploy:
   npx wrangler deploy
6) Re-run:
   node .\audit-sitemap.mjs

Expected final audit:
NOINDEX: 0
404: 0
5XX: 0
CANONICAL_MISMATCH: 0
